from node import Node

class Dlist:
    def __init__(self):
        self.first_node = None
        self.last_node = None

    # def insert_before(self, node, new_node):
    #     new_node.next = node
    #     if node.prev == None:
    #         self.first_node = new_node
    #     else:
    #         new_node.prev = node.prev
    #         node.prev.next = new_node

    def insert_to_front(self, value):
        new_node = Node(value)
        if self.first_node == None:
            self.first_node = new_node
            self.last_node = new_node
        else:
            new_node.next = self.first_node
            self.first_node.prev = new_node
            self.first_node = new_node
        return self

    def insert_to_back(self,value):
        new_node = Node(value)
        if self.last_node == None:
            self.last_node = new_node
            self.first_node = new_node
        else:
            self.last_node.next = new_node
            new_node.prev = self.last_node
            self.last_node = new_node
        return self 

    def printForward(self):
        print("Print Forward")
        current_node = self.first_node
        count = 1
        while current_node != None:
            print(f"Node {count} Value: {current_node.value}")
            current_node = current_node.next
            count += 1
        return self

    def printBackward(self):
        print("Print Backward")
        current_node = self.last_node
        count = 1
        while current_node != None:
            print(f"Node {count} Value: {current_node.value}")
            current_node = current_node.prev
            count += 1
        return self

